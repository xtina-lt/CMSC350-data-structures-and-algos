/***************************************************************************************
 *  PROJECT #2 POLYNOMIALS  
 *  CMSC 350: James Huskins  
 *  Written by: Christina Torres
 *  PURPOSE:
 *  - Examine a file of polynomials
 *  - Determines whether the polynomials in that file are in strictly ascending order *
 ***************************************************************************************/
public class Main {
    public static void main(String[] args) {
        new OrderedList();
    }
}